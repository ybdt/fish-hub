tinymce.addI18n('de',{
"Insert/edit a XH plugin call": "XH Plugin einfügen/bearbeiten",
"Insert/edit the XH plugin call here - without {{{}}}": "XH Pluginaufruf hier einfügen oder bearbeiten - ohne {{{}}}",
});