tinymce.addI18n('sk',{
"Insert/edit a XH plugin call": "Vložiť/upraviť XH plugin",
"Insert/edit the XH plugin call here - without {{{}}}": "Sem vložte alebo upravte príkaz XH pluginu - bez {{{}}}",
});