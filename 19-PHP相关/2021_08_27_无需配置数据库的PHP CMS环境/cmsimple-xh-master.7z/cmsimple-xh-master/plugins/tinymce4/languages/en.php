<?php
$plugin_tx['tinymce4']['cf_init'] = "The size of the toolbar";
$plugin_tx['tinymce4']['cf_CDN_alt_src']="alternate CDN Source";
$plugin_tx['tinymce4']['cf_CDN']="CDN Version if checked";
$plugin_tx['tinymce4']['pageheader']="%s. Level pageheader";
$plugin_tx['tinymce4']['menu_main']="About...";
$plugin_tx['tinymce4']['cf_utf-8_marker']="<p>Internal usage. <strong>Do not change!</strong></p>";