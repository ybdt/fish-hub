<?php

$plugin_cf['fa']['require_auto']="";

$plugin_cf['fa']['fontawesome_version']="4";
$plugin_cf['fa']['fontawesome_shim']="";
