<?php

$plugin_tx['jquery']['cf_autoload']="Check to auto-load the libraries on every page.";
$plugin_tx['jquery']['cf_autoload_libraries']="Whether to auto-load only jQuery or jQuery together with jQueryUI.";
$plugin_tx['jquery']['cf_load_migrate']="Whether to load the Migrate-plugin or not. See <a target=\"_blank\" href=\"https://jquery.com/download/#jquery-migrate-plugin\">https://jquery.com/download/#jquery-migrate-plugin</a> for more informations.";
