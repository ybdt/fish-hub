<?php

$plugin_mcf['jquery']['version_core']="function:jquery_getCoreVersions";
$plugin_mcf['jquery']['version_ui']="function:jquery_getUiVersions";
$plugin_mcf['jquery']['version_migrate']="function:jquery_getMigrateVersions";
$plugin_mcf['jquery']['load_migrate']="bool";
$plugin_mcf['jquery']['autoload']="bool";
$plugin_mcf['jquery']['autoload_libraries']="enum:jQuery,jQuery & jQueryUI";

?>