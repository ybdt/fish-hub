<?php

$plugin_cf['jquery']['version_core']="1.12.4";
$plugin_cf['jquery']['version_ui']="1.12.1";
$plugin_cf['jquery']['version_migrate']="jquery-migrate-1.4.1.min.js";
$plugin_cf['jquery']['load_migrate']="true";
$plugin_cf['jquery']['autoload']="";
$plugin_cf['jquery']['autoload_libraries']="jQuery";
