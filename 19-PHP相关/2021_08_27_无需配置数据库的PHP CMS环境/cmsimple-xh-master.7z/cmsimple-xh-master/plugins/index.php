<?php

die('access denied');

?>
