Wichtige Änderungen
===================

Hier werden für einen anstehenden release die Informationen gesammelt, die in der Release Ankündigung vermerkt werden müssen.

für Neuinstallation
-------------------
1.
2.
3.

für Updates
-----------
1.
2.
3.
