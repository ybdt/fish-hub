<?php

/**
 * @return string
 */
function gblink() {}

/**
 * @return void
 */
function custom_404() {}
