A Pen created at CodePen.io. You can find this one at http://codepen.io/riogrande/pen/dYMBgj

 This is example #1 from responsive overlay menu framework. Full menu with submenus. This is a framework for creating responsive cross-browser overlay menus. Made with css3, jquery and ionicons. Fork and star on github https://github.com/marioloncarek/responsive-overlay-menu